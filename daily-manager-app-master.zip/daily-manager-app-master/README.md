# daily-manager-app
- Daily manager app is mainly designed for those people who are very busy
scheduled and usually forget the things they want to buy and quantities of each
item they want to buy. Our app gives utmost importance to customization of the
items and categories and also it allows us to add images related to events inorder
to remember firmly

## Main features

- registration of new user using either making an account sending an otp to the phone number or by Gmail or even by using facebook login
- authentication of the already registered users
- user can any no of categories like grocery, shopping list etc of his/her choice.
- And in each category the user can add any no of items
- Each item added could also be added along with an image
- Data about can be shared ,deleted or updated.
- Trigger can have track of the todo list,also user can add meetings
- user can also maintain a personal diary

## Additional features:
- The user can send email and SMS using the send option available
- If the user forgot password an email verification mechanism is also present

## Team members

- Akula koteswarudu
- S.Sai.Sandeep
- Ch.Rajesh
- Nallani Rohan Rao

